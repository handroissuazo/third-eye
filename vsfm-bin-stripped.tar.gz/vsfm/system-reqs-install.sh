#!/bin/sh
sudo apt-get install libgtk2.0-dev freeglut3-dev libdevil-dev libglew-dev unzip
sudo apt-get install libboost-all-dev
sudo apt-get install gsl-bin
sudo apt-get install libgsl0-dev
sudo apt-get install liblapack-dev -y
sudo apt-get install liblapack3 -y
sudo apt-get install libopenblas-base -y
sudo apt-get install libopenblas-dev -y
sudo apt-get install ffmpeg
